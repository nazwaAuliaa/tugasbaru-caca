<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class  hello extends CI_Controller {

	Public function data($data)
	{
		
		echo "<h1> hello </h1>";
        // ke folder view/welcome_massage
	}

    Public function tampil() {
        $data['judul'] = "Halaman Tampil";
        $data['deskripsi'] = "ini deskripsi";
    
        //parsing data
        $this->load->view('tampil', $data);
    }
    
}

    