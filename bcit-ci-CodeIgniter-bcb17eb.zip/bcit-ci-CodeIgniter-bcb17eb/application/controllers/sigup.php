<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class sigup extends CI_Controller {


	
	public function index()
	{
		
		$this->load->view('welcome_message');
		echo "ini adalah controler sigup";
			
	}
	
	public function home(){
		echo "ini adalah home ";
	}
	
	public function login(){
		echo "ini adalah login";
	}

	}