<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('welcome_message');
	}
		public function login()
	{
		$data['jurusan']="RPL";
		$data['kelas']='12';
		$this->load->view('login',$data);
	}
	
	public function home(){
		echo "ini home";
		
	}

}
