<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class data extends CI_Controller {

	
	public function index()
	{
		
		echo "<h1> data </h1>";
	}
}
